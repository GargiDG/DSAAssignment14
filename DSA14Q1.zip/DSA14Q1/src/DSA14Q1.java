class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        next = null;
    }
}

public class DSA14Q1 {
    public static void removeLoop(Node head) {
        if (head == null || head.next == null) {
            return;
        }

        Node slow = head;
        Node fast = head;

        // Detect the loop
        boolean hasLoop = false;
        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
            if (slow == fast) {
                hasLoop = true;
                break;
            }
        }

        if (hasLoop) {
            // Find the start of the loop
            slow = head;
            while (slow.next != fast.next) {
                slow = slow.next;
                fast = fast.next;
            }

            // Remove the loop
            fast.next = null;
            slow.next=null;
        }
    }

    public static void main(String[] args) {
        // Create a linked list with a loop
        Node head = new Node(1);
        head.next = new Node(3);
        head.next.next = new Node(4);
        head.next.next.next = new Node(2);
        head.next.next.next.next = head.next.next;


        // Remove the loop
        removeLoop(head);

        // Print the resulting list
       // System.out.println(head.data);
        
        
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            if (current.next == null) {
                break;
            }
            current = current.next;
    }

  


    }




}
