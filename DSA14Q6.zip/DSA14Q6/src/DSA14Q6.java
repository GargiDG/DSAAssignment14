
class ListNode {
    int val;
    ListNode next;

    ListNode(int val) {
        this.val = val;
        this.next = null;
    }
}

public class DSA14Q6 {
    public static ListNode leftShift(ListNode head, int k) {
        if (head == null || head.next == null || k == 0) {
            return head;
        }

        int length = getLength(head);

        // Adjust k if it's larger than the length of the list
        k = k % length;

        if (k == 0) {
            return head;
        }

        ListNode current = head;

        // Traverse to the (k-1)-th node
        for (int i = 0; i < k - 1; i++) {
            current = current.next;
        }

        // Connect the last node to the head of the list
        ListNode lastNode = current;
        while (lastNode.next != null) {
            lastNode = lastNode.next;
        }
        lastNode.next = head;

        // Update the head and break the link at the (k-1)-th node
        head = current.next;
        current.next = null;

        return head;
    }

    public static int getLength(ListNode head) {
        int length = 0;
        ListNode current = head;
        while (current != null) {
            length++;
            current = current.next;
        }
        return length;
    }

    public static void printList(ListNode head) {
        ListNode current = head;
        while (current != null) {
            System.out.print(current.val + " ");
            current = current.next;
        }
    }

    public static void main(String[] args) {
        // Create the linked list
        ListNode head = new ListNode(2);
        head.next = new ListNode(4);
        head.next.next = new ListNode(7);
        head.next.next.next = new ListNode(8);
        head.next.next.next.next = new ListNode(9);

        // Left-shift the list by k = 3
        ListNode shiftedList = leftShift(head, 3);

        // Print the shifted list
        printList(shiftedList);
    }
}
