
import java.util.*;

class ListNode {
    int val;
    ListNode next;

    ListNode(int val) {
        this.val = val;
        this.next = null;
    }
}

public class DSA14Q7 {
    public static int[] nextLargerNodes(ListNode head) {
        if (head == null) {
            return new int[0];
        }

        List<Integer> values = new ArrayList<>();
        ListNode current = head;

        // Store the values of the nodes in a list
        while (current != null) {
            values.add(current.val);
            current = current.next;
        }

        int[] result = new int[values.size()];
        Stack<Integer> stack = new Stack<>();

        // Iterate through the values list in reverse order
        for (int i = values.size() - 1; i >= 0; i--) {
            int value = values.get(i);

            // Pop elements from the stack until we find a greater value
            while (!stack.isEmpty() && stack.peek() <= value) {
                stack.pop();
            }

            // If stack is empty, there is no greater value
            if (stack.isEmpty()) {
                result[i] = 0;
            } else {
                result[i] = stack.peek();
            }

            stack.push(value);
        }

        return result;
    }

    public static void main(String[] args) {
        // Create the linked list
        ListNode head = new ListNode(2);
        head.next = new ListNode(1);
        head.next.next = new ListNode(5);

        // Find the next greater node for each node
        int[] result = nextLargerNodes(head);

        // Print the result
        for (int value : result) {
            System.out.print(value + " ");
        }
    }
}
